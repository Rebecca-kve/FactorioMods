if mods["BrimStuff"] then
    add_recipe_to_start("basic-chemistry", "basic-chemical-plant")
end
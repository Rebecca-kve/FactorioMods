data.raw.inserter["burner-inserter"].localised_name = "Mechanical Inserter"
data.raw.inserter["burner-inserter"].energy_source = {
	type = "void"
}
data.raw.inserter["burner-inserter"].filter_count = 5